window.onscroll = function () {
  stickyNavbar();
};
var header = document.getElementById("main-header");
var sticky = header.offsetTop;

function stickyNavbar() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
// SWIPER
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 1,
  spaceBetween: 30,
  loop: true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
});
// hidden flags
jQuery(document).ready(function ($) {
  // Hide containers initially
  $(".hideable-container").hide();

  // Handle button click to toggle visibility and change button content
  $(".show-hide-button").on("click", function () {
    $(".hideable-container").toggle();
    if ($(".hideable-container").is(":visible")) {
      $(this).find(".secondary-btn").text("Show Less Countries");
    } else {
      $(this).find(".secondary-btn").text("View All Countries");
    }
  });
});
// Swiper - 2;
var swiper = new Swiper(".mySwiper-2", {
  slidesPerView: 1,
  spaceBetween: 0,
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});
// EMAIL NOTIFICATION
// Get the modal
var modal = document.getElementById("thankYouModal");

// Get the <span> element that closes the modal
var closeBtn = document.getElementsByClassName("close")[0];

// Get the submit button
var submitBtn = document.querySelector(".submitBtn");
var submitBtn2 = document.querySelector(".submitBtn2");

// Get the thank you message
var thankYouMessage = document.getElementById("thankYouMessage");

// When the user clicks on the button, open the modal
submitBtn.addEventListener("click", function (event) {
  event.preventDefault(); // Prevent default button click behavior

  var email = document.querySelector(".heroForm input[name='email']").value;

  // You can further process the email here, like sending it to a server

  // Display the modal
  modal.style.display = "block";

  // Automatically fade out after 5 seconds (5000 milliseconds)
  setTimeout(function () {
    modal.style.display = "none";
  }, 5000);
});
submitBtn2.addEventListener("click", function (event) {
  event.preventDefault(); // Prevent default button click behavior

  var email = document.querySelector(".heroForm input[name='email']").value;

  // You can further process the email here, like sending it to a server

  // Display the modal
  modal.style.display = "block";

  // Automatically fade out after 5 seconds (5000 milliseconds)
  setTimeout(function () {
    modal.style.display = "none";
  }, 5000);
});

// When the user clicks on <span> (x), close the modal
closeBtn.onclick = function () {
  modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
// FAQ SECTION
function toggleFaq(element) {
  var answer = element.nextElementSibling;
  answer.style.display = answer.style.display === "block" ? "none" : "block";
  var icon = element.querySelector("i");
  element.classList.toggle("active");
  icon.classList.toggle("fa-chevron-down");
  icon.classList.toggle("fa-chevron-up");
}
