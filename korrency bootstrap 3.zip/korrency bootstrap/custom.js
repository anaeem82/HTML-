window.onscroll = function () {
	stickyNavbar();
};
var header = document.getElementById("main-header");
var sticky = header.offsetTop;

function stickyNavbar() {
	if (window.pageYOffset > sticky) {
		header.classList.add("sticky");
	} else {
		header.classList.remove("sticky");
	}
}

// hidden flags
jQuery(document).ready(function ($) {
	// Hide containers initially
	$(".hideable-container").hide();

	// Handle button click to toggle visibility and change button content
	$(".show-hide-button").on("click", function () {
		$(".hideable-container").toggle();
		if ($(".hideable-container").is(":visible")) {
			$(this).find(".secondary-btn").text("Show Less Countries");
		} else {
			$(this).find(".secondary-btn").text("View All Countries");
		}
	});
});

// FORM POP UP
document.addEventListener("DOMContentLoaded", function () {
	const openPopupBtn = document.getElementById("openPopupBtn");
	const closePopupBtn = document.getElementById("closePopupBtn");
	const popupContainer = document.getElementById("popupContainer");
	const popupForm = document.getElementById("popupForm");

	// Open popup
	openPopupBtn.addEventListener("click", function () {
		popupContainer.style.display = "block";
		setTimeout(() => {
			popupContainer.classList.add("fadeIn");
		}, 10);
	});

	// Close popup
	function closePopup() {
		popupContainer.classList.remove("fadeIn");
		setTimeout(() => {
			popupContainer.style.display = "none";
		}, 500);
	}

	closePopupBtn.addEventListener("click", closePopup);

	// Form submission
	popupForm.addEventListener("submit", function (event) {
		event.preventDefault(); // Prevent default form submission
		// Handle form submission logic here
		// For demonstration, let's assume the form is submitted successfully
		// You can replace this with your own form submission logic
		// Close the popup after successful submission
		closePopup();
	});
});

//EMAIL SUBMISSION
// Get the modal
var modal = document.getElementById("thankYouModal");

// Get the <span> element that closes the modal
var closeBtn = document.getElementsByClassName("close")[0];

// Get the submit buttons
var submitBtns = document.querySelectorAll(".submitBtn");

// Get the thank you message
var thankYouMessage = document.getElementById("thankYouMessage");

// Function to handle form submission and display thank you modal
function handleSubmit(event) {
	event.preventDefault(); // Prevent default button click behavior

	var email = document.querySelector(".heroForm input[name='email']").value;

	// You can further process the email here, like sending it to a server

	// Display the modal
	modal.style.display = "block";

	// Automatically fade out after 5 seconds (5000 milliseconds)
	setTimeout(function () {
		modal.style.display = "none";
	}, 5000);
}

// Add event listeners to all submit buttons
submitBtns.forEach(function (submitBtn) {
	submitBtn.addEventListener("click", handleSubmit);
});

// When the user clicks on <span> (x), close the modal
closeBtn.onclick = function () {
	modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
};

// FAQ
function toggleFaq(element) {
	var answer = element.nextElementSibling;
	var allAnswers = document.querySelectorAll(".faq-answers");
	var allBoxes = document.querySelectorAll(".faq-box");

	// Close all answers
	allAnswers.forEach((ans) => {
		if (ans !== answer && ans.style.display === "block") {
			ans.style.display = "none";
		}
	});

	// Remove active class from all boxes
	allBoxes.forEach((box) => {
		if (box !== element && box.classList.contains("active")) {
			box.classList.remove("active");
			var icon = box.querySelector("i");
			icon.classList.remove("fa-chevron-up");
			icon.classList.add("fa-chevron-down");
		}
	});

	if (answer.style.display === "block") {
		// Close selected answer
		answer.style.display = "none";
		element.classList.remove("active"); // Remove active class from current box
	} else {
		// Open selected answer
		answer.style.display = "block";
		element.classList.add("active"); // Add active class to current box
	}

	var icon = element.querySelector("i");
	icon.classList.toggle("fa-chevron-down");
	icon.classList.toggle("fa-chevron-up");
}
// FULL STORY
function toggleStory(event) {
	event.preventDefault();
	var storyFull = document.querySelector(".story-full");
	var readMoreBtn = event.target;

	// Add transition class
	storyFull.classList.add("transition");

	// Toggle show class
	storyFull.classList.toggle("show");

	if (storyFull.classList.contains("show")) {
		readMoreBtn.textContent = "Read Less";
	} else {
		readMoreBtn.textContent = "Read More";
	}
}
